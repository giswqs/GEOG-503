import GISTools

import GISTools.classes
import GISTools.functions
import GISTools.analysis

### call the classes module from the GISTools package
me = GISTools.classes.Person()
me.setname("Qiusheng")
me.greeting()

### class the functions module from the GISTools package
GISTools.functions.printmsg()

### call the analysis module frrom the GISTools package
workspace = r"C:\geog503\data"
clip_fc = r"C:\geog503\data\basin.shp"
output_dir = r"C:\geog503\data\Results"
GISTools.analysis.ClipFeatureClasses(workspace,clip_fc,output_dir)






