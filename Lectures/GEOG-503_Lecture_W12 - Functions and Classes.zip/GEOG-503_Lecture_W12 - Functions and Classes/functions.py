### define a function without return statement
def printmsg(major="GIS", univ = "Binghamton University"):
    print("My major is {0}, and I am from {1}.".format(major,univ))

### define a function with return statement
def addint(x = 0, y = 0):
    result = x + y
    return result

### distinguish between a script and a modules
if __name__ == '__main__':
    printmsg()





