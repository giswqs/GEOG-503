__author__ = 'Qiusheng'
import arcpy
import os
import sys

print __file__
print os.path.basename(__file__)
print os.path.dirname(__file__)

scriptpath = sys.path[0]
print scriptpath

scriptpath2 = os.getcwd()
print scriptpath2

toolpath = os.path.dirname(scriptpath)
print toolpath

tooldatapath = os.path.join(toolpath,"ToolData")
print tooldatapath

datapath = os.path.join(tooldatapath,"basin.shp")
print datapath